<footer>
    <div class="container">
      <div class="row">
        <div class="col-lg-12">
          <p>Copyright © <?= date('Y') ?> 
          
          <br>Web Designed by Universitas Nurtanio Bandung</p>
        </div>
      </div>
    </div>
  </footer>

  <!-- Scripts -->
  <script src="vendor/jquery/jquery.min.js"></script>
  <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
  <script src="assets/js/owl-carousel.js"></script>
  <script src="assets/js/animation.js"></script>
  <script src="assets/js/imagesloaded.js"></script>
  <script src="assets/js/custom.js"></script>

</body>
</html>