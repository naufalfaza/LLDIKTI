***************
Git Push
***************

1. git add .
2. git commit -m "LOMBA LLDIKTI 4"
3. git branch -M main
4. git push -u origin main

***************
Git Pull
***************
1. git pull https://github.com/naufalfaza/LLDIKTI.git



